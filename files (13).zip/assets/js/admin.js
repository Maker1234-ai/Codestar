jQuery(document).ready(function($) {
    // Job Duplicator Form Handler
    $('#job-duplicator-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submit = $form.find('button[type="submit"]');
        const $spinner = $form.find('.spinner');
        const $results = $('#duplication-results');
        
        // Show loading state
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        $results.html('<div class="notice notice-info"><p>Processing job duplication...</p></div>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'duplicate_jobs',
                nonce: $('#_wpnonce').val(),
                job_id: $('#job_id').val(),
                company_id: $('#company_id').val(),
                locations: $('#locations').val()
            },
            success: function(response) {
                if (response.success) {
                    let html = '<div class="notice notice-success"><h3>Successfully duplicated jobs:</h3><ul>';
                    response.data.forEach(function(job) {
                        html += `<li>New job created for location "${job.location}": ` +
                               `<a href="${job.url}" target="_blank">View Job</a></li>`;
                    });
                    html += '</ul></div>';
                    $results.html(html);
                } else {
                    $results.html(`<div class="notice notice-error"><p>Error: ${response.data}</p></div>`);
                }
            },
            error: function(xhr, status, error) {
                $results.html(`<div class="notice notice-error"><p>Error: ${error}</p></div>`);
                console.log('AJAX Error:', xhr.responseText);
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });

    // API Key Form Handler
    $('#api-key-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submit = $form.find('button[type="submit"]');
        const $spinner = $form.find('.spinner');
        const $result = $('#api-result');
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        $result.html('<div class="notice notice-info"><p>Saving API key...</p></div>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'verify_api_key',
                nonce: $('#_wpnonce').val(),
                api_key: $('#api_key').val()
            },
            success: function(response) {
                if (response.success) {
                    $result.html(`<div class="notice notice-success"><p>${response.data}</p></div>`);
                } else {
                    $result.html(`<div class="notice notice-error"><p>Error: ${response.data}</p></div>`);
                }
            },
            error: function(xhr, status, error) {
                $result.html(`<div class="notice notice-error"><p>Error: ${error}</p></div>`);
                console.log('AJAX Error:', xhr.responseText);
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
});