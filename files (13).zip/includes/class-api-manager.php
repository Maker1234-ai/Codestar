<?php
if (!defined('ABSPATH')) {
    exit;
}

class WP_Management_API_Manager {
    public function __construct() {
        add_action('wp_ajax_verify_api_key', array($this, 'handle_api_verification'));
    }

    public function render_page() {
        $api_key = get_option('wp_management_api_key', WP_MANAGEMENT_DEFAULT_API_KEY);
        include WP_MANAGEMENT_PATH . 'templates/api-key.php';
    }

    public function handle_api_verification() {
        check_ajax_referer('wp_management_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $api_key = sanitize_text_field($_POST['api_key']);
        update_option('wp_management_api_key', $api_key);
        wp_send_json_success('API key saved successfully');
    }
}