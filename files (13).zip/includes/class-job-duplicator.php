<?php
if (!defined('ABSPATH')) {
    exit;
}

class WP_Management_Job_Duplicator {
    public function __construct() {
        add_action('wp_ajax_duplicate_jobs', array($this, 'handle_job_duplication'));
    }

    public function render_page() {
        include WP_MANAGEMENT_PATH . 'templates/job-duplicator.php';
    }

    public function handle_job_duplication() {
        check_ajax_referer('wp_management_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $job_id = intval($_POST['job_id']);
        $locations = array_map('trim', explode(',', sanitize_textarea_field($_POST['locations'])));
        $locations = array_slice($locations, 0, 50); // Limit to 50 locations

        $results = array();
        foreach ($locations as $location) {
            $new_job_id = $this->duplicate_job($job_id, $location);
            if ($new_job_id) {
                $this->track_job($job_id, $new_job_id, $location);
                $results[] = array(
                    'location' => $location,
                    'job_id' => $new_job_id,
                    'url' => get_permalink($new_job_id)
                );
            }
        }

        wp_send_json_success($results);
    }

    private function duplicate_job($job_id, $location) {
        $original_job = get_post($job_id);
        if (!$original_job || $original_job->post_type !== 'job_listing') {
            return false;
        }

        $new_job = array(
            'post_title' => $original_job->post_title . ' - ' . $location,
            'post_content' => $original_job->post_content,
            'post_status' => 'publish',
            'post_type' => 'job_listing',
            'post_author' => $original_job->post_author
        );

        $new_job_id = wp_insert_post($new_job);

        if ($new_job_id) {
            // Copy meta data
            $meta_keys = get_post_custom_keys($job_id);
            if ($meta_keys) {
                foreach ($meta_keys as $key) {
                    $meta_values = get_post_meta($job_id, $key, true);
                    update_post_meta($new_job_id, $key, $meta_values);
                }
            }

            // Update location
            update_post_meta($new_job_id, '_job_location', $location);

            // Copy taxonomies
            $taxonomies = get_object_taxonomies('job_listing');
            foreach ($taxonomies as $taxonomy) {
                $terms = wp_get_object_terms($job_id, $taxonomy, array('fields' => 'ids'));
                wp_set_object_terms($new_job_id, $terms, $taxonomy);
            }
        }

        return $new_job_id;
    }

    private function track_job($original_id, $new_id, $location) {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'wp_management_jobs',
            array(
                'original_job_id' => $original_id,
                'new_job_id' => $new_id,
                'location' => $location,
                'created_by' => wp_get_current_user()->user_login,
                'created_at' => current_time('mysql', true)
            ),
            array('%d', '%d', '%s', '%s', '%s')
        );
    }
}

// Function to render the job duplicator page
function wp_management_job_duplicator_page() {
    $duplicator = new WP_Management_Job_Duplicator();
    $duplicator->render_page();
}