<div class="wrap">
    <h1><?php echo esc_html__('WP Management Dashboard', 'wp-management'); ?></h1>

    <div class="wp-management-container">
        <h2><?php echo esc_html__('Recent Job Duplications', 'wp-management'); ?></h2>

        <?php
        global $wpdb;
        
        // Get recent duplicated jobs
        $jobs = $wpdb->get_results("
            SELECT j.*, 
                   oj.post_title as original_title,
                   nj.post_title as new_title,
                   c.post_title as company_name
            FROM {$wpdb->prefix}wp_management_jobs j
            LEFT JOIN {$wpdb->posts} oj ON oj.ID = j.original_job_id
            LEFT JOIN {$wpdb->posts} nj ON nj.ID = j.new_job_id
            LEFT JOIN {$wpdb->posts} c ON c.ID = j.company_id
            ORDER BY j.created_at DESC
            LIMIT 20
        ");
        
        if ($jobs && !empty($jobs)) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Original Job', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('New Job', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('Location', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('Company', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('Created By', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('Date', 'wp-management'); ?></th>
                        <th><?php echo esc_html__('Actions', 'wp-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($jobs as $job) : ?>
                        <tr>
                            <td>
                                <a href="<?php echo esc_url(get_edit_post_link($job->original_job_id)); ?>">
                                    <?php echo esc_html($job->original_title); ?>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(get_edit_post_link($job->new_job_id)); ?>">
                                    <?php echo esc_html($job->new_title); ?>
                                </a>
                            </td>
                            <td><?php echo esc_html($job->location); ?></td>
                            <td><?php echo esc_html($job->company_name ?: 'Original Company'); ?></td>
                            <td><?php echo esc_html($job->created_by); ?></td>
                            <td><?php echo esc_html(get_date_from_gmt($job->created_at, 'Y-m-d H:i:s')); ?></td>
                            <td>
                                <a href="<?php echo esc_url(get_permalink($job->new_job_id)); ?>" 
                                   class="button button-small" 
                                   target="_blank">
                                    <?php echo esc_html__('View', 'wp-management'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div class="notice notice-info">
                <p><?php echo esc_html__('No jobs have been duplicated yet.', 'wp-management'); ?></p>
            </div>
        <?php endif; ?>

        <div class="quick-links" style="margin-top: 20px;">
            <a href="<?php echo admin_url('admin.php?page=wp-management-job-duplicator'); ?>" class="button button-primary">
                <?php echo esc_html__('Go to Job Duplicator', 'wp-management'); ?>
            </a>
            <a href="<?php echo admin_url('admin.php?page=wp-management-api'); ?>" class="button">
                <?php echo esc_html__('API Key Settings', 'wp-management'); ?>
            </a>
            <a href="<?php echo admin_url('admin.php?page=wp-management-settings'); ?>" class="button">
                <?php echo esc_html__('Settings', 'wp-management'); ?>
            </a>
        </div>
    </div>
</div>

<style>
.wp-management-container {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.quick-links {
    margin-top: 20px;
}

.quick-links .button {
    margin-right: 10px;
}

.notice {
    margin: 10px 0;
}
</style>