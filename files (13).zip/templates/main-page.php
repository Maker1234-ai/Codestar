<div class="wrap">
    <h1><?php echo esc_html__('WP Management Dashboard', 'wp-management'); ?></h1>
    
    <div class="wp-management-container">
        <h2><?php echo esc_html__('Job Duplication History', 'wp-management'); ?></h2>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php echo esc_html__('Original Job', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('New Job', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Location', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Company', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Created By', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Created At', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Status', 'wp-management'); ?></th>
                    <th><?php echo esc_html__('Actions', 'wp-management'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($jobs)) : ?>
                    <?php foreach ($jobs as $job) : ?>
                        <tr>
                            <td>
                                <a href="<?php echo esc_url(get_edit_post_link($job->original_job_id)); ?>">
                                    <?php echo esc_html($job->original_title); ?>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(get_edit_post_link($job->new_job_id)); ?>">
                                    <?php echo esc_html($job->new_title); ?>
                                </a>
                            </td>
                            <td><?php echo esc_html($job->location); ?></td>
                            <td><?php echo esc_html($job->company_name ?: 'Original Company'); ?></td>
                            <td><?php echo esc_html($job->created_by); ?></td>
                            <td><?php echo esc_html(get_date_from_gmt($job->created_at, 'Y-m-d H:i:s')); ?></td>
                            <td>
                                <span class="status-<?php echo esc_attr($job->status); ?>">
                                    <?php echo esc_html(ucfirst($job->status)); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(get_permalink($job->new_job_id)); ?>" 
                                   class="button button-small" 
                                   target="_blank">
                                    <?php echo esc_html__('View', 'wp-management'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8"><?php echo esc_html__('No jobs have been duplicated yet.', 'wp-management'); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php
        // Add pagination
        $total_pages = ceil($total_items / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('&laquo;'),
                'next_text' => __('&raquo;'),
                'total' => $total_pages,
                'current' => $current_page
            ));
            echo '</div></div>';
        }
        ?>
    </div>
</div>

<style>
.status-active {
    color: #46b450;
}
.status-inactive {
    color: #dc3232;
}
.wp-management-container {
    margin-top: 20px;
}
</style>