<div class="wrap">
    <h1><?php echo esc_html__('Settings', 'wp-management'); ?></h1>

    <div class="wp-management-container">
        <form method="post" action="options.php">
            <?php settings_fields('wp_management_settings'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wp_management_max_jobs">
                            <?php echo esc_html__('Maximum Jobs', 'wp-management'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="wp_management_max_jobs" 
                               name="wp_management_max_jobs" 
                               value="<?php echo esc_attr($max_jobs); ?>" 
                               min="1" 
                               max="1000">
                        <p class="description">
                            <?php echo esc_html__('Maximum number of jobs to process per minute (1-1000)', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wp_management_delay">
                            <?php echo esc_html__('Processing Delay', 'wp-management'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="wp_management_delay" 
                               name="wp_management_delay" 
                               value="<?php echo esc_attr($delay); ?>" 
                               min="0" 
                               max="60">
                        <p class="description">
                            <?php echo esc_html__('Delay between job creation (seconds)', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
</div>