<?php
/**
 * Plugin Name: WP Management
 * Plugin URI: https://jtech.com/wp-management
 * Description: A comprehensive WordPress plugin for job management with duplication features and API key management
 * Version: 1.0.0
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: J Tech
 * Author URI: https://jtech.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-management
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_MANAGEMENT_VERSION', '1.0.0');
define('WP_MANAGEMENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_MANAGEMENT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WP_MANAGEMENT_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WP_MANAGEMENT_DEFAULT_API_KEY', 'HindiEnglish@1234');

// Plugin Classes
class WP_Management_Job_Duplicator {
    public function __construct() {
        add_action('wp_ajax_duplicate_jobs', array($this, 'handle_job_duplication'));
    }

    public function render_page() {
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/job-duplicator.php';
    }

    public function handle_job_duplication() {
        check_ajax_referer('wp_management_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $job_id = intval($_POST['job_id']);
        $company_id = !empty($_POST['company_id']) ? intval($_POST['company_id']) : 0;
        $locations = array_map('trim', explode(',', sanitize_textarea_field($_POST['locations'])));
        $locations = array_slice($locations, 0, 50);

        $results = array();
        foreach ($locations as $location) {
            $new_job_id = $this->duplicate_job($job_id, $location, $company_id);
            if ($new_job_id) {
                $this->track_job($job_id, $new_job_id, $location, $company_id);
                $results[] = array(
                    'location' => $location,
                    'job_id' => $new_job_id,
                    'url' => get_permalink($new_job_id)
                );
            }
        }

        wp_send_json_success($results);
    }

    private function duplicate_job($job_id, $location, $company_id = 0) {
        $original_job = get_post($job_id);
        if (!$original_job || $original_job->post_type !== 'job_listing') {
            return false;
        }

        $new_job = array(
            'post_title' => $original_job->post_title . ' - ' . $location,
            'post_content' => $original_job->post_content,
            'post_status' => 'publish',
            'post_type' => 'job_listing',
            'post_author' => $original_job->post_author
        );

        $new_job_id = wp_insert_post($new_job);

        if ($new_job_id) {
            $meta_keys = get_post_custom_keys($job_id);
            if ($meta_keys) {
                foreach ($meta_keys as $key) {
                    if ($key !== '_job_location') {
                        $meta_values = get_post_meta($job_id, $key, true);
                        update_post_meta($new_job_id, $key, $meta_values);
                    }
                }
            }

            update_post_meta($new_job_id, '_job_location', $location);
            
            if ($company_id > 0) {
                update_post_meta($new_job_id, '_company_id', $company_id);
            }

            $taxonomies = get_object_taxonomies('job_listing');
            foreach ($taxonomies as $taxonomy) {
                $terms = wp_get_object_terms($job_id, $taxonomy, array('fields' => 'ids'));
                wp_set_object_terms($new_job_id, $terms, $taxonomy);
            }
        }

        return $new_job_id;
    }

    private function track_job($original_id, $new_id, $location, $company_id) {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'wp_management_jobs',
            array(
                'original_job_id' => $original_id,
                'new_job_id' => $new_id,
                'location' => $location,
                'company_id' => $company_id,
                'created_by' => wp_get_current_user()->user_login,
                'created_at' => current_time('mysql', true)
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s')
        );
    }
}

class WP_Management_API_Manager {
    public function __construct() {
        add_action('wp_ajax_verify_api_key', array($this, 'handle_api_verification'));
    }

    public function render_page() {
        $api_key = get_option('wp_management_api_key', WP_MANAGEMENT_DEFAULT_API_KEY);
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/api-key.php';
    }

    public function handle_api_verification() {
        check_ajax_referer('wp_management_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $api_key = sanitize_text_field($_POST['api_key']);
        update_option('wp_management_api_key', $api_key);
        wp_send_json_success('API key saved successfully');
    }
}

class WP_Management_Settings_Manager {
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings() {
        register_setting('wp_management_settings', 'wp_management_max_jobs');
        register_setting('wp_management_settings', 'wp_management_delay');
    }

    public function render_page() {
        $max_jobs = get_option('wp_management_max_jobs', 50);
        $delay = get_option('wp_management_delay', 0);
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/settings.php';
    }
}

// Initialize the plugin
function wp_management_init() {
    global $wp_management_job_duplicator, $wp_management_api_manager, $wp_management_settings_manager;
    
    $wp_management_job_duplicator = new WP_Management_Job_Duplicator();
    $wp_management_api_manager = new WP_Management_API_Manager();
    $wp_management_settings_manager = new WP_Management_Settings_Manager();
}
add_action('plugins_loaded', 'wp_management_init');

// Add admin menu
function wp_management_admin_menu() {
    add_menu_page(
        'WP Management',
        'WP Management',
        'manage_options',
        'wp-management',
        'wp_management_dashboard_page',
        'dashicons-admin-tools',
        30
    );

    add_submenu_page(
        'wp-management',
        'Job Duplicator',
        'Job Duplicator',
        'manage_options',
        'wp-management-job-duplicator',
        'wp_management_job_duplicator_page'
    );

    add_submenu_page(
        'wp-management',
        'API Key',
        'API Key',
        'manage_options',
        'wp-management-api',
        'wp_management_api_page'
    );

    add_submenu_page(
        'wp-management',
        'Settings',
        'Settings',
        'manage_options',
        'wp-management-settings',
        'wp_management_settings_page'
    );
}
add_action('admin_menu', 'wp_management_admin_menu');

// Include page rendering functions
function wp_management_dashboard_page() {
    include WP_MANAGEMENT_PLUGIN_DIR . 'templates/dashboard.php';
}

function wp_management_job_duplicator_page() {
    global $wp_management_job_duplicator;
    $wp_management_job_duplicator->render_page();
}

function wp_management_api_page() {
    global $wp_management_api_manager;
    $wp_management_api_manager->render_page();
}

function wp_management_settings_page() {
    global $wp_management_settings_manager;
    $wp_management_settings_manager->render_page();
}

// Register activation hook
register_activation_hook(__FILE__, 'wp_management_activate');

function wp_management_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wp_management_jobs (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        original_job_id bigint(20) NOT NULL,
        new_job_id bigint(20) NOT NULL,
        location varchar(255) NOT NULL,
        company_id bigint(20) DEFAULT NULL,
        created_by varchar(255) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY original_job_id (original_job_id),
        KEY new_job_id (new_job_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    add_option('wp_management_api_key', WP_MANAGEMENT_DEFAULT_API_KEY);
    add_option('wp_management_max_jobs', 50);
    add_option('wp_management_delay', 0);
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'wp_management_deactivate');

function wp_management_deactivate() {
    // Cleanup if needed
}

// Enqueue admin scripts and styles
function wp_management_admin_enqueue_scripts($hook) {
    if (strpos($hook, 'wp-management') !== false) {
        wp_enqueue_style(
            'wp-management-admin',
            WP_MANAGEMENT_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            WP_MANAGEMENT_VERSION
        );

        wp_enqueue_script(
            'wp-management-admin',
            WP_MANAGEMENT_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            WP_MANAGEMENT_VERSION,
            true
        );

        wp_localize_script('wp-management-admin', 'wpManagement', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp_management_nonce')
        ));
    }
}
add_action('admin_enqueue_scripts', 'wp_management_admin_enqueue_scripts');