// Update the API key verification part in your admin.js file

jQuery(document).ready(function($) {
    // ... (keep existing job duplicator code) ...

    // API Key Form
    $('#api-key-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submit = $form.find('button[type="submit"]');
        const $spinner = $form.find('.spinner');
        const $result = $('#api-result');
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        $result.html('');
        
        $.ajax({
            url: wpManagement.ajaxurl,
            type: 'POST',
            data: {
                action: 'verify_api_key',
                nonce: $('#_wpnonce').val(),
                api_key: $('#api_key').val()
            },
            success: function(response) {
                if (response.success) {
                    $result.html(`
                        <div class="notice notice-success">
                            <p>${response.data}</p>
                        </div>
                    `);
                    // Reload page after successful verification
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    $result.html(`
                        <div class="notice notice-error">
                            <p>${response.data}</p>
                        </div>
                    `);
                }
            },
            error: function() {
                $result.html(`
                    <div class="notice notice-error">
                        <p>An error occurred while verifying the API key.</p>
                    </div>
                `);
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
});