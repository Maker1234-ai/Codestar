<?php
if (!defined('ABSPATH')) {
    exit;
}

class WP_Management_Settings_Manager {
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings() {
        register_setting('wp_management_settings', 'wp_management_max_jobs');
        register_setting('wp_management_settings', 'wp_management_delay');
    }

    public function render_page() {
        $max_jobs = get_option('wp_management_max_jobs', 50);
        $delay = get_option('wp_management_delay', 0);
        include WP_MANAGEMENT_PATH . 'templates/settings.php';
    }
}