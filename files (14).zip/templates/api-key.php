<div class="wrap">
    <h1><?php echo esc_html__('API Key Management', 'wp-management'); ?></h1>

    <div class="wp-management-container">
        <?php if ($is_verified): ?>
            <div class="notice notice-success">
                <p><?php echo esc_html__('API key is verified and active.', 'wp-management'); ?></p>
            </div>
        <?php endif; ?>

        <form id="api-key-form">
            <?php wp_nonce_field('wp_management_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="api_key"><?php echo esc_html__('API Key', 'wp-management'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="api_key" 
                               name="api_key" 
                               value="<?php echo esc_attr($api_key); ?>" 
                               class="regular-text"
                               required>
                        <p class="description">
                            <?php echo esc_html__('Enter the valid API key to activate the plugin features.', 'wp-management'); ?>
                        </p>
                        <?php if (!$is_verified): ?>
                            <p class="description" style="color: #dc3232;">
                                <?php echo esc_html__('Please enter a valid API key to use the plugin features.', 'wp-management'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <div class="submit-container">
                <button type="submit" class="button button-primary">
                    <?php echo esc_html__('Verify API Key', 'wp-management'); ?>
                </button>
                <span class="spinner"></span>
            </div>
        </form>

        <div id="api-result" class="api-result"></div>
    </div>
</div>

<style>
.wp-management-container {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.submit-container {
    margin-top: 20px;
}

.spinner {
    float: none;
    margin-left: 10px;
}

.api-result {
    margin-top: 20px;
}

.notice {
    margin: 0 0 20px 0;
}
</style>