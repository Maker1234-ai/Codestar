<div class="wrap">
    <h1><?php echo esc_html__('WP Management Dashboard', 'wp-management'); ?></h1>

    <div class="wp-management-container">
        <h2><?php echo esc_html__('Quick Links', 'wp-management'); ?></h2>
        <ul class="quick-links">
            <li>
                <a href="<?php echo admin_url('admin.php?page=wp-management-job-duplicator'); ?>" class="button button-primary">
                    <?php echo esc_html__('Job Duplicator', 'wp-management'); ?>
                </a>
            </li>
            <li>
                <a href="<?php echo admin_url('admin.php?page=wp-management-api'); ?>" class="button">
                    <?php echo esc_html__('API Key Settings', 'wp-management'); ?>
                </a>
            </li>
            <li>
                <a href="<?php echo admin_url('admin.php?page=wp-management-settings'); ?>" class="button">
                    <?php echo esc_html__('Settings', 'wp-management'); ?>
                </a>
            </li>
        </ul>
    </div>
</div>