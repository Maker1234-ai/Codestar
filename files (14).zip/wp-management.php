// Update the WP_Management_API_Manager class in your main plugin file

class WP_Management_API_Manager {
    private $valid_api_key = 'Jobreposter@09@78@23@12#1';

    public function __construct() {
        add_action('wp_ajax_verify_api_key', array($this, 'handle_api_verification'));
    }

    public function render_page() {
        $api_key = get_option('wp_management_api_key', '');
        $is_verified = $this->is_api_key_valid(get_option('wp_management_api_key', ''));
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/api-key.php';
    }

    public function handle_api_verification() {
        try {
            check_ajax_referer('wp_management_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new Exception('Insufficient permissions.');
            }

            $api_key = sanitize_text_field($_POST['api_key']);
            
            if (empty($api_key)) {
                throw new Exception('API key cannot be empty.');
            }

            // Check if the API key matches the valid key
            if ($api_key !== $this->valid_api_key) {
                throw new Exception('Invalid API key. Please enter the correct API key.');
            }

            // If we get here, the API key is valid
            update_option('wp_management_api_key', $api_key);
            
            // Log the successful verification
            $this->log_api_verification(true);
            
            wp_send_json_success('API key verified and saved successfully.');

        } catch (Exception $e) {
            $this->log_api_verification(false);
            wp_send_json_error($e->getMessage());
        }
    }

    private function is_api_key_valid($api_key) {
        return $api_key === $this->valid_api_key;
    }

    private function log_api_verification($success) {
        $user = wp_get_current_user();
        $log_entry = sprintf(
            "[%s] User %s %s verify API key from %s\n",
            current_time('mysql'),
            $user->user_login,
            $success ? 'successfully' : 'failed to',
            $_SERVER['REMOTE_ADDR']
        );
        
        // You might want to log this to a file or database
        error_log($log_entry);
    }
}