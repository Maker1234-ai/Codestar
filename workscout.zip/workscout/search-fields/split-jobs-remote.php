    <!-- Panel Dropdown -->
    <div class="panel-dropdown " id="tax-job_type-panel">
        <a href="#"><?php esc_html_e('Remote', 'workscout'); ?></a>
        <div class="panel-dropdown-content checkboxes ">
            <div class="row  ">
                <div class="panel-checkboxes-container ">


                    <input type="checkbox" class="input-checkbox" name="remote_position" id="remote_position" placeholder="Location" value="1">
                    <label for="remote_position" id="remote_position_label"><?php esc_html_e('Remote positions only', 'workscout'); ?></label>


                </div>
            </div>
        </div>
    </div>

    